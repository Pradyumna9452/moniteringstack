#!/bin/bash
# ============================================
# ZABBIX STACK BACKUP SCRIPT
# Usage: ./backup.sh
# ============================================
set -e
# Create backup directory with timestamp
BACKUP_DIR="/root/zabbix-backup-$(date +%Y%m%d_%H%M%S)"
mkdir -p $BACKUP_DIR
echo "============================================"
echo "  ZABBIX STACK BACKUP"
echo "  $(date)"
echo "============================================"
echo ""
# 1. Backup all config files and docker-compose
echo "[1/8] Backing up config files..."
cp -r ~/zabbix-stack $BACKUP_DIR/zabbix-stack-files
# 2. Backup PostgreSQL (Zabbix database)
echo "[2/8] Backing up Zabbix PostgreSQL database..."
docker exec zabbix-postgres pg_dump -U zabbix zabbix | gzip > $BACKUP_DIR/zabbix_postgres_backup.sql.gz
# 3. Backup MariaDB (GLPI database)
echo "[3/8] Backing up GLPI MariaDB database..."
docker exec glpi-mariadb mysqldump -uglpi -pglpi_password glpi 2>/dev/null | gzip > $BACKUP_DIR/glpi_mariadb_backup.sql.gz
# 4. Backup Grafana data
echo "[4/8] Backing up Grafana data..."
docker run --rm -v zabbix-stack_grafana_data:/data -v $BACKUP_DIR:/backup alpine tar czf /backup/grafana_data.tar.gz -C /data .
# 5. Backup VictoriaMetrics data
echo "[5/8] Backing up VictoriaMetrics data..."
docker run --rm -v zabbix-stack_victoriametrics_data:/data -v $BACKUP_DIR:/backup alpine tar czf /backup/victoriametrics_data.tar.gz -C /data .
# 6. Backup GLPI files
echo "[6/8] Backing up GLPI files..."
docker run --rm -v zabbix-stack_glpi_data:/data -v $BACKUP_DIR:/backup alpine tar czf /backup/glpi_data.tar.gz -C /data . 2>/dev/null || echo "  - glpi_data volume not found, skipping"
docker run --rm -v zabbix-stack_glpi_config:/data -v $BACKUP_DIR:/backup alpine tar czf /backup/glpi_config.tar.gz -C /data . 2>/dev/null || echo "  - glpi_config volume not found, skipping"
docker run --rm -v zabbix-stack_glpi_files:/data -v $BACKUP_DIR:/backup alpine tar czf /backup/glpi_files.tar.gz -C /data . 2>/dev/null || echo "  - glpi_files volume not found, skipping"
# 7. List all Docker volumes for reference
echo "[7/8] Listing Docker volumes..."
docker volume ls | grep -E "zabbix|glpi|grafana|victoria" > $BACKUP_DIR/docker_volumes_list.txt
# 8. Save container info
echo "[8/8] Saving container info..."
docker ps -a > $BACKUP_DIR/docker_containers.txt
docker images > $BACKUP_DIR/docker_images.txt
# Show backup summary
echo ""
echo "============================================"
echo "  BACKUP COMPLETE"
echo "============================================"
echo "Location: $BACKUP_DIR"
echo ""
ls -lh $BACKUP_DIR
echo ""
echo "Total size: $(du -sh $BACKUP_DIR | cut -f1)"
echo "============================================"
