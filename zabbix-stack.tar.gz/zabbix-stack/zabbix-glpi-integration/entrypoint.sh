#!/bin/bash
#
# Entrypoint script for Zabbix-GLPI Integration container
#

set -e

echo "=============================================="
echo "Zabbix-GLPI Integration Service"
echo "=============================================="
echo "Starting at: $(date)"
echo ""

# Initialize database
echo "Initializing database..."
python -c "from database import init_database; init_database()"
echo "Database initialized at: ${DATABASE_PATH:-/data/zabbix_glpi.db}"
echo ""

# Run initial inventory sync if enabled
if [ "${RUN_INITIAL_SYNC:-false}" = "true" ]; then
    echo "Running initial inventory sync..."
    python inventory_sync.py || echo "Initial sync completed with warnings"
    echo ""
fi

# Start the webhook server
echo "Starting webhook server on port ${WEBHOOK_PORT:-5002}..."
echo ""

# Use gunicorn for production, flask dev server for debug
if [ "${DEBUG:-false}" = "true" ]; then
    echo "Running in DEBUG mode"
    exec python webhook_server.py
else
    exec gunicorn \
        --bind "0.0.0.0:${WEBHOOK_PORT:-5002}" \
        --workers "${GUNICORN_WORKERS:-2}" \
        --threads "${GUNICORN_THREADS:-4}" \
        --timeout 30 \
        --access-logfile - \
        --error-logfile - \
        --capture-output \
        webhook_server:app
fi
