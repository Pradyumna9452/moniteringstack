# Zabbix-GLPI Integration Package
__version__ = '1.0.0'
