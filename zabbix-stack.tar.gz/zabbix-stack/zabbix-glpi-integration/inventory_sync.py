#!/usr/bin/env python3
"""
Zabbix to GLPI Inventory Synchronization
Pulls host inventory from Zabbix and syncs to GLPI as Computer assets

Run via cron or as a scheduled task:
    */60 * * * * /usr/bin/python3 /app/inventory_sync.py >> /var/log/inventory_sync.log 2>&1
"""

import os
import sys
import logging
import argparse
from datetime import datetime
from typing import Dict, Any, List, Optional

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import (
    LOG_LEVEL, LOG_FORMAT, ZABBIX_TO_GLPI_FIELD_MAP,
    INVENTORY_SYNC_ENABLED
)
from glpi_client import GLPIClient
from zabbix_client import ZabbixClient
from database import (
    init_database, save_asset_mapping, get_glpi_asset_by_host_id,
    start_sync_session, complete_sync_session
)

# Configure logging
logging.basicConfig(level=getattr(logging, LOG_LEVEL), format=LOG_FORMAT)
logger = logging.getLogger(__name__)


def map_inventory_fields(zabbix_host: Dict[str, Any]) -> Dict[str, Any]:
    """
    Map Zabbix host inventory fields to GLPI Computer fields
    
    Args:
        zabbix_host: Zabbix host object with inventory data
        
    Returns:
        GLPI Computer data dictionary
    """
    glpi_data = {}
    
    # Always set the name from host
    host_name = zabbix_host.get('name') or zabbix_host.get('host', '')
    glpi_data['name'] = host_name
    
    # Get inventory data
    inventory = zabbix_host.get('inventory', {})
    
    # Skip if inventory is empty or disabled
    if not inventory or inventory == []:
        logger.debug(f"No inventory data for host {host_name}")
        glpi_data['comment'] = f"Synced from Zabbix. Host ID: {zabbix_host.get('hostid')}"
        return glpi_data
    
    # Map fields according to configuration
    for zabbix_field, glpi_field in ZABBIX_TO_GLPI_FIELD_MAP.items():
        value = inventory.get(zabbix_field, '')
        
        if value:
            # Handle special fields that need lookup/conversion
            if glpi_field in ['operatingsystems_id', 'computermodels_id', 
                              'manufacturers_id', 'locations_id']:
                # These would need GLPI lookup - store as text in comment for now
                # In production, implement lookup functions
                glpi_data['comment'] = glpi_data.get('comment', '') + f"\n{zabbix_field}: {value}"
            else:
                glpi_data[glpi_field] = value
    
    # Add interface IPs to comment
    interfaces = zabbix_host.get('interfaces', [])
    if interfaces:
        ips = [iface.get('ip', '') for iface in interfaces if iface.get('ip')]
        if ips:
            glpi_data['comment'] = glpi_data.get('comment', '') + f"\nIP Addresses: {', '.join(ips)}"
    
    # Add Zabbix reference
    glpi_data['comment'] = (glpi_data.get('comment', '') + 
                           f"\n\nSynced from Zabbix at {datetime.utcnow().isoformat()}"
                           f"\nZabbix Host ID: {zabbix_host.get('hostid')}")
    
    return glpi_data


def determine_itemtype(zabbix_host: Dict[str, Any]) -> str:
    """
    Determine GLPI item type based on Zabbix host properties
    
    Args:
        zabbix_host: Zabbix host object
        
    Returns:
        GLPI itemtype ('Computer', 'NetworkEquipment', etc.)
    """
    inventory = zabbix_host.get('inventory', {})
    
    if inventory:
        host_type = inventory.get('type', '').lower()
        
        # Map common device types
        network_types = ['switch', 'router', 'firewall', 'access point', 'ap', 'network']
        if any(nt in host_type for nt in network_types):
            return 'NetworkEquipment'
        
        printer_types = ['printer', 'mfp', 'multifunction']
        if any(pt in host_type for pt in printer_types):
            return 'Printer'
    
    # Default to Computer
    return 'Computer'


def sync_host_to_glpi(
    zabbix_host: Dict[str, Any],
    glpi_client: GLPIClient
) -> Dict[str, Any]:
    """
    Sync a single Zabbix host to GLPI
    
    Args:
        zabbix_host: Zabbix host object
        glpi_client: GLPI API client
        
    Returns:
        Result dictionary with status
    """
    host_id = zabbix_host.get('hostid')
    host_name = zabbix_host.get('name') or zabbix_host.get('host', 'Unknown')
    
    try:
        # Check if already synced
        existing = get_glpi_asset_by_host_id(host_id)
        
        # Map inventory fields
        glpi_data = map_inventory_fields(zabbix_host)
        itemtype = determine_itemtype(zabbix_host)
        
        if existing and existing.get('glpi_computer_id'):
            # Update existing
            glpi_id = existing['glpi_computer_id']
            glpi_data['id'] = glpi_id
            
            # Currently only supporting Computer updates
            if itemtype == 'Computer':
                result = glpi_client.create_or_update_computer(glpi_data)
                if result:
                    save_asset_mapping(host_id, host_name, result, itemtype)
                    return {'status': 'updated', 'glpi_id': result}
        else:
            # Create new
            if itemtype == 'Computer':
                glpi_id = glpi_client.create_or_update_computer(glpi_data)
                if glpi_id:
                    save_asset_mapping(host_id, host_name, glpi_id, itemtype)
                    return {'status': 'created', 'glpi_id': glpi_id}
        
        return {'status': 'skipped', 'reason': f'Unsupported itemtype: {itemtype}'}
        
    except Exception as e:
        logger.error(f"Error syncing host {host_name}: {e}")
        return {'status': 'error', 'error': str(e)}


def run_sync(dry_run: bool = False, host_filter: str = None) -> Dict[str, Any]:
    """
    Run full inventory synchronization
    
    Args:
        dry_run: If True, only report what would be done
        host_filter: Optional hostname filter (substring match)
        
    Returns:
        Sync results summary
    """
    if not INVENTORY_SYNC_ENABLED and not dry_run:
        logger.warning("Inventory sync is disabled in configuration")
        return {'status': 'disabled'}
    
    logger.info("Starting inventory sync from Zabbix to GLPI")
    
    # Start sync session
    session_id = start_sync_session('inventory')
    
    results = {
        'processed': 0,
        'created': 0,
        'updated': 0,
        'skipped': 0,
        'errors': 0,
        'hosts': []
    }
    
    try:
        # Get hosts from Zabbix
        with ZabbixClient() as zabbix:
            hosts = zabbix.get_hosts(with_inventory=True)
            logger.info(f"Retrieved {len(hosts)} hosts from Zabbix")
        
        # Filter if specified
        if host_filter:
            hosts = [h for h in hosts if host_filter.lower() in 
                    (h.get('name', '') + h.get('host', '')).lower()]
            logger.info(f"Filtered to {len(hosts)} hosts matching '{host_filter}'")
        
        if dry_run:
            logger.info("DRY RUN - No changes will be made")
            for host in hosts:
                host_name = host.get('name') or host.get('host', 'Unknown')
                itemtype = determine_itemtype(host)
                existing = get_glpi_asset_by_host_id(host.get('hostid'))
                action = 'UPDATE' if existing else 'CREATE'
                logger.info(f"  [{action}] {host_name} -> {itemtype}")
                results['hosts'].append({
                    'name': host_name,
                    'action': action,
                    'itemtype': itemtype
                })
            results['processed'] = len(hosts)
            return results
        
        # Sync to GLPI
        with GLPIClient() as glpi:
            for host in hosts:
                host_name = host.get('name') or host.get('host', 'Unknown')
                
                result = sync_host_to_glpi(host, glpi)
                results['processed'] += 1
                
                if result['status'] == 'created':
                    results['created'] += 1
                    logger.info(f"Created: {host_name} -> GLPI #{result.get('glpi_id')}")
                elif result['status'] == 'updated':
                    results['updated'] += 1
                    logger.info(f"Updated: {host_name} -> GLPI #{result.get('glpi_id')}")
                elif result['status'] == 'skipped':
                    results['skipped'] += 1
                    logger.debug(f"Skipped: {host_name} - {result.get('reason')}")
                elif result['status'] == 'error':
                    results['errors'] += 1
                    logger.error(f"Error: {host_name} - {result.get('error')}")
                
                results['hosts'].append({
                    'name': host_name,
                    'status': result['status'],
                    'glpi_id': result.get('glpi_id')
                })
        
        # Complete sync session
        complete_sync_session(
            session_id,
            hosts_processed=results['processed'],
            hosts_created=results['created'],
            hosts_updated=results['updated'],
            errors=results['errors'],
            status='completed' if results['errors'] == 0 else 'completed_with_errors'
        )
        
        logger.info(f"Sync completed: {results['processed']} processed, "
                   f"{results['created']} created, {results['updated']} updated, "
                   f"{results['errors']} errors")
        
        return results
        
    except Exception as e:
        logger.exception(f"Sync failed: {e}")
        complete_sync_session(session_id, status='failed', details=str(e))
        return {'status': 'error', 'error': str(e)}


def main():
    """CLI entry point"""
    parser = argparse.ArgumentParser(
        description='Sync Zabbix host inventory to GLPI assets'
    )
    parser.add_argument(
        '--dry-run', '-n',
        action='store_true',
        help='Show what would be synced without making changes'
    )
    parser.add_argument(
        '--host', '-H',
        type=str,
        help='Filter to hosts matching this substring'
    )
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose output'
    )
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Initialize database
    init_database()
    
    # Run sync
    results = run_sync(dry_run=args.dry_run, host_filter=args.host)
    
    # Print summary
    print("\n" + "=" * 50)
    print("SYNC SUMMARY")
    print("=" * 50)
    
    if 'error' in results:
        print(f"Status: FAILED - {results['error']}")
        sys.exit(1)
    elif results.get('status') == 'disabled':
        print("Status: DISABLED (set INVENTORY_SYNC_ENABLED=true to enable)")
        sys.exit(0)
    else:
        print(f"Processed: {results.get('processed', 0)}")
        print(f"Created:   {results.get('created', 0)}")
        print(f"Updated:   {results.get('updated', 0)}")
        print(f"Skipped:   {results.get('skipped', 0)}")
        print(f"Errors:    {results.get('errors', 0)}")
        
        if args.dry_run:
            print("\n[DRY RUN - No changes were made]")
        
        sys.exit(0 if results.get('errors', 0) == 0 else 1)


if __name__ == '__main__':
    main()
