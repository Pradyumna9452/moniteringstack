#!/usr/bin/env python3
"""
Zabbix API Client for GLPI Integration
Handles event acknowledgment, host inventory retrieval, and tag management
"""

import logging
import requests
from typing import Optional, Dict, Any, List

from config import ZABBIX_URL, ZABBIX_USER, ZABBIX_PASSWORD, ZABBIX_API_TOKEN

logger = logging.getLogger(__name__)


class ZabbixClient:
    """Zabbix JSON-RPC API Client"""
    
    def __init__(self):
        self.url = ZABBIX_URL
        self.auth_token = None
        self._request_id = 1
        self._request_timeout = 30
        
    def _api_request(self, method: str, params: Dict[str, Any] = None) -> Optional[Any]:
        """
        Make a Zabbix API request
        
        Args:
            method: API method name (e.g., 'event.acknowledge')
            params: Method parameters
            
        Returns:
            API response result or None on error
        """
        try:
            payload = {
                'jsonrpc': '2.0',
                'method': method,
                'params': params or {},
                'id': self._request_id,
            }
            self._request_id += 1
            
            headers = {'Content-Type': 'application/json-rpc'}
            
            # Zabbix 7.x uses Authorization header instead of auth in payload
            if self.auth_token and method != 'user.login':
                headers['Authorization'] = f'Bearer {self.auth_token}'
            
            # Use API token in header if configured (preferred for Zabbix 7.x)
            if ZABBIX_API_TOKEN and method != 'user.login':
                headers['Authorization'] = f'Bearer {ZABBIX_API_TOKEN}'
            
            response = requests.post(
                self.url,
                json=payload,
                headers=headers,
                timeout=self._request_timeout
            )
            
            if response.status_code == 200:
                data = response.json()
                if 'error' in data:
                    logger.error(f"Zabbix API error: {data['error']}")
                    return None
                return data.get('result')
            else:
                logger.error(f"Zabbix API HTTP error: {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"Zabbix API request failed: {e}")
            return None
    
    def login(self) -> bool:
        """
        Authenticate with Zabbix API
        
        Returns:
            True if successful
        """
        try:
            # If using API token, no login needed
            if ZABBIX_API_TOKEN:
                logger.info("Using Zabbix API token authentication")
                return True
            
            # Zabbix 7.x uses 'username', older versions use 'user'
            result = self._api_request('user.login', {
                'username': ZABBIX_USER,
                'password': ZABBIX_PASSWORD,
            })
            
            if result:
                self.auth_token = result
                logger.info("Zabbix login successful")
                return True
            return False
            
        except Exception as e:
            logger.error(f"Zabbix login failed: {e}")
            return False
    
    def logout(self):
        """Logout from Zabbix API"""
        if self.auth_token and not ZABBIX_API_TOKEN:
            try:
                self._api_request('user.logout', {})
            except Exception:
                pass
            self.auth_token = None
    
    def __enter__(self):
        """Context manager entry"""
        self.login()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.logout()
    
    # =========================================================================
    # Event Operations
    # =========================================================================
    
    def acknowledge_event(
        self,
        event_ids: List[str],
        message: str = "Acknowledged by GLPI Integration",
        action: int = 6,  # Default: Ack + Message
        severity: Optional[int] = None
    ) -> bool:
        """
        Acknowledge Zabbix event(s)
        
        Args:
            event_ids: List of event IDs to acknowledge
            message: Acknowledgment message
            action: Bitmask of actions:
                    1 = Close problem
                    2 = Acknowledge event
                    4 = Add message
                    8 = Change severity
                    16 = Unacknowledge event
                    32 = Suppress event
                    64 = Unsuppress event
                    128 = Change event rank to cause
                    256 = Change event rank to symptom
            severity: New severity (if action includes 8)
            
        Returns:
            True if successful
        """
        try:
            if not self.auth_token and not ZABBIX_API_TOKEN:
                if not self.login():
                    return False
            
            params = {
                'eventids': event_ids if isinstance(event_ids, list) else [event_ids],
                'message': message,
                'action': action,
            }
            
            if severity is not None and (action & 8):
                params['severity'] = severity
            
            result = self._api_request('event.acknowledge', params)
            
            if result:
                logger.info(f"Acknowledged events: {event_ids}")
                return True
            return False
            
        except Exception as e:
            logger.error(f"Event acknowledge failed: {e}")
            return False
    
    def get_event(self, event_id: str) -> Optional[Dict[str, Any]]:
        """Get event details by ID"""
        try:
            if not self.auth_token and not ZABBIX_API_TOKEN:
                if not self.login():
                    return None
            
            result = self._api_request('event.get', {
                'eventids': [event_id],
                'output': 'extend',
                'selectTags': 'extend',
                'selectHosts': ['hostid', 'name'],
            })
            
            if result:
                return result[0] if result else None
            return None
            
        except Exception as e:
            logger.error(f"Get event failed: {e}")
            return None
    
    def get_problem(self, event_id: str) -> Optional[Dict[str, Any]]:
        """Get problem details by event ID"""
        try:
            if not self.auth_token and not ZABBIX_API_TOKEN:
                if not self.login():
                    return None
            
            result = self._api_request('problem.get', {
                'eventids': [event_id],
                'output': 'extend',
                'selectTags': 'extend',
            })
            
            if result:
                return result[0] if result else None
            return None
            
        except Exception as e:
            logger.error(f"Get problem failed: {e}")
            return None
    
    # =========================================================================
    # Host & Inventory Operations
    # =========================================================================
    
    def get_hosts(self, with_inventory: bool = True) -> List[Dict[str, Any]]:
        """
        Get all monitored hosts with optional inventory data
        
        Args:
            with_inventory: Include inventory data
            
        Returns:
            List of host objects
        """
        try:
            if not self.auth_token and not ZABBIX_API_TOKEN:
                if not self.login():
                    return []
            
            params = {
                'output': ['hostid', 'host', 'name', 'status'],
                'selectInterfaces': ['ip', 'dns', 'type'],
                'filter': {'status': 0},  # Only enabled hosts
            }
            
            if with_inventory:
                params['selectInventory'] = 'extend'
            
            result = self._api_request('host.get', params)
            return result or []
            
        except Exception as e:
            logger.error(f"Get hosts failed: {e}")
            return []
    
    def get_host_by_name(self, hostname: str, with_inventory: bool = True) -> Optional[Dict[str, Any]]:
        """
        Get host by hostname or visible name
        
        Args:
            hostname: The host's technical name or visible name
            with_inventory: Include inventory data
            
        Returns:
            Host object or None
        """
        try:
            if not self.auth_token and not ZABBIX_API_TOKEN:
                if not self.login():
                    return None
            
            params = {
                'output': ['hostid', 'host', 'name', 'status'],
                'selectInterfaces': ['ip', 'dns', 'type'],
                'filter': {'host': hostname},
            }
            
            if with_inventory:
                params['selectInventory'] = 'extend'
            
            result = self._api_request('host.get', params)
            
            if result:
                return result[0] if result else None
            
            # Try by visible name
            params['filter'] = {'name': hostname}
            result = self._api_request('host.get', params)
            
            return result[0] if result else None
            
        except Exception as e:
            logger.error(f"Get host by name failed: {e}")
            return None
    
    def get_host_by_id(self, host_id: str, with_inventory: bool = True) -> Optional[Dict[str, Any]]:
        """Get host by ID"""
        try:
            if not self.auth_token and not ZABBIX_API_TOKEN:
                if not self.login():
                    return None
            
            params = {
                'hostids': [host_id],
                'output': ['hostid', 'host', 'name', 'status'],
                'selectInterfaces': ['ip', 'dns', 'type'],
            }
            
            if with_inventory:
                params['selectInventory'] = 'extend'
            
            result = self._api_request('host.get', params)
            return result[0] if result else None
            
        except Exception as e:
            logger.error(f"Get host by ID failed: {e}")
            return None
    
    # =========================================================================
    # Tag Operations (for storing GLPI ticket ID)
    # =========================================================================
    
    def add_event_tag(self, event_id: str, tag: str, value: str) -> bool:
        """
        Add a tag to an event (via acknowledge with suppress action)
        Note: Zabbix 6.0+ supports event tags via acknowledge
        
        For older versions, store the mapping in the database instead.
        """
        try:
            # In Zabbix 6.0+, we can use event.acknowledge with a message
            # that includes the ticket info. The actual tag storage
            # is done via our local database.
            return True
        except Exception as e:
            logger.error(f"Add event tag failed: {e}")
            return False
    
    # =========================================================================
    # Trigger Operations
    # =========================================================================
    
    def get_trigger(self, trigger_id: str) -> Optional[Dict[str, Any]]:
        """Get trigger details by ID"""
        try:
            if not self.auth_token and not ZABBIX_API_TOKEN:
                if not self.login():
                    return None
            
            result = self._api_request('trigger.get', {
                'triggerids': [trigger_id],
                'output': 'extend',
                'selectHosts': ['hostid', 'name'],
            })
            
            return result[0] if result else None
            
        except Exception as e:
            logger.error(f"Get trigger failed: {e}")
            return None
    
    # =========================================================================
    # API Info
    # =========================================================================
    
    def get_api_version(self) -> Optional[str]:
        """Get Zabbix API version"""
        try:
            result = self._api_request('apiinfo.version', {})
            return result
        except Exception:
            return None
