#!/usr/bin/env python3
"""
GLPI API Client for Zabbix Integration
Handles all GLPI operations: sessions, tickets, assets, followups
"""

import logging
import base64
import requests
from typing import Optional, Dict, Any, List

from config import (
    GLPI_URL, GLPI_USER, GLPI_PASSWORD, GLPI_APP_TOKEN, GLPI_USER_TOKEN,
    GLPI_ENTITY_ID, GLPI_DEFAULT_USER_ID, GLPI_DEFAULT_GROUP_ID, GLPI_STATUS
)

logger = logging.getLogger(__name__)


class GLPIClient:
    """GLPI REST API Client with full ticket lifecycle support"""
    
    def __init__(self):
        self.base_url = GLPI_URL.rstrip('/')
        self.session_token = None
        self.app_token = GLPI_APP_TOKEN
        self._request_timeout = 30
        
    def _get_headers(self) -> Dict[str, str]:
        """Build headers for API requests"""
        headers = {'Content-Type': 'application/json'}
        # Only add App-Token if it's actually set (non-empty)
        if self.app_token:
            headers['App-Token'] = self.app_token
        if self.session_token:
            headers['Session-Token'] = self.session_token
        return headers
    
    def init_session(self) -> bool:
        """Initialize GLPI session using user token or basic auth"""
        try:
            if GLPI_USER_TOKEN:
                headers = {
                    'Content-Type': 'application/json',
                    'Authorization': f'user_token {GLPI_USER_TOKEN}'
                }
            else:
                credentials = base64.b64encode(f'{GLPI_USER}:{GLPI_PASSWORD}'.encode()).decode()
                headers = {
                    'Content-Type': 'application/json',
                    'Authorization': f'Basic {credentials}'
                }
            
            if self.app_token:
                headers['App-Token'] = self.app_token
            
            response = requests.get(
                f'{self.base_url}/initSession',
                headers=headers,
                timeout=self._request_timeout
            )
            
            if response.status_code == 200:
                data = response.json()
                self.session_token = data.get('session_token')
                logger.info("GLPI session initialized successfully")
                return True
            else:
                logger.error(f"Failed to init GLPI session: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Error initializing GLPI session: {e}")
            return False
    
    def kill_session(self):
        """Terminate GLPI session"""
        try:
            if self.session_token:
                requests.get(
                    f'{self.base_url}/killSession',
                    headers=self._get_headers(),
                    timeout=10
                )
                logger.debug("GLPI session terminated")
        except Exception as e:
            logger.warning(f"Error killing GLPI session: {e}")
        finally:
            self.session_token = None
    
    def __enter__(self):
        """Context manager entry - auto init session"""
        self.init_session()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - auto kill session"""
        self.kill_session()
    
    # =========================================================================
    # Ticket Operations
    # =========================================================================
    
    def create_ticket(
        self,
        name: str,
        content: str,
        urgency: int = 3,
        priority: int = 3,
        itemtype: Optional[str] = None,
        items_id: Optional[int] = None,
        external_id: Optional[str] = None,
        **kwargs
    ) -> Optional[int]:
        """
        Create a new GLPI ticket
        
        Args:
            name: Ticket title
            content: Ticket description (HTML supported)
            urgency: 1-5 (5 = most urgent)
            priority: 1-5 (5 = highest priority)
            itemtype: Asset type (e.g., 'Computer', 'NetworkEquipment')
            items_id: Asset ID in GLPI
            external_id: External reference (stored in ticket for deduplication)
            
        Returns:
            Ticket ID if created, None otherwise
        """
        try:
            if not self.session_token and not self.init_session():
                return None
            
            ticket_data = {
                'input': {
                    'name': name,
                    'content': content,
                    'urgency': urgency,
                    'priority': priority,
                    'type': 1,  # Incident
                    'status': GLPI_STATUS['NEW'],
                    'entities_id': GLPI_ENTITY_ID,
                }
            }
            
            # Add optional fields
            if GLPI_DEFAULT_USER_ID:
                ticket_data['input']['_users_id_assign'] = GLPI_DEFAULT_USER_ID
                ticket_data['input']['status'] = GLPI_STATUS['ASSIGNED']
            
            if GLPI_DEFAULT_GROUP_ID:
                ticket_data['input']['_groups_id_assign'] = GLPI_DEFAULT_GROUP_ID
                ticket_data['input']['status'] = GLPI_STATUS['ASSIGNED']
            
            # Add any additional fields
            ticket_data['input'].update(kwargs)
            
            response = requests.post(
                f'{self.base_url}/Ticket',
                headers=self._get_headers(),
                json=ticket_data,
                timeout=self._request_timeout
            )
            
            if response.status_code in [200, 201]:
                data = response.json()
                ticket_id = data.get('id')
                logger.info(f"Created GLPI ticket #{ticket_id}: {name}")
                
                # Link asset if provided
                if itemtype and items_id:
                    self.link_asset_to_ticket(ticket_id, itemtype, items_id)
                
                return ticket_id
            else:
                logger.error(f"Failed to create ticket: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Error creating GLPI ticket: {e}")
            return None
    
    def update_ticket(
        self,
        ticket_id: int,
        status: Optional[int] = None,
        solution: Optional[str] = None,
        **kwargs
    ) -> bool:
        """
        Update an existing GLPI ticket
        
        Args:
            ticket_id: The GLPI ticket ID
            status: New status code (use GLPI_STATUS constants)
            solution: Solution text (for closing tickets)
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if not self.session_token and not self.init_session():
                return False
            
            update_data = {'input': {'id': ticket_id}}
            
            if status is not None:
                update_data['input']['status'] = status
            
            update_data['input'].update(kwargs)
            
            response = requests.put(
                f'{self.base_url}/Ticket/{ticket_id}',
                headers=self._get_headers(),
                json=update_data,
                timeout=self._request_timeout
            )
            
            if response.status_code == 200:
                logger.info(f"Updated GLPI ticket #{ticket_id}")
                
                # Add solution if provided (for closing)
                if solution and status in [GLPI_STATUS['SOLVED'], GLPI_STATUS['CLOSED']]:
                    self.add_solution(ticket_id, solution)
                
                return True
            else:
                logger.error(f"Failed to update ticket: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Error updating GLPI ticket: {e}")
            return False
    
    def close_ticket(self, ticket_id: int, solution: str) -> bool:
        """
        Close a ticket with solution
        
        Args:
            ticket_id: The GLPI ticket ID
            solution: Solution/resolution text
            
        Returns:
            True if successful
        """
        # First add solution
        self.add_solution(ticket_id, solution)
        # Then close
        return self.update_ticket(ticket_id, status=GLPI_STATUS['CLOSED'])
    
    def add_followup(self, ticket_id: int, content: str, is_private: bool = False) -> Optional[int]:
        """
        Add a follow-up comment to a ticket
        
        Args:
            ticket_id: The GLPI ticket ID
            content: Comment content (HTML supported)
            is_private: Whether the comment is private
            
        Returns:
            Followup ID if created, None otherwise
        """
        try:
            if not self.session_token and not self.init_session():
                return None
            
            followup_data = {
                'input': {
                    'items_id': ticket_id,
                    'itemtype': 'Ticket',
                    'content': content,
                    'is_private': 1 if is_private else 0,
                }
            }
            
            response = requests.post(
                f'{self.base_url}/ITILFollowup',
                headers=self._get_headers(),
                json=followup_data,
                timeout=self._request_timeout
            )
            
            if response.status_code in [200, 201]:
                data = response.json()
                followup_id = data.get('id')
                logger.info(f"Added followup #{followup_id} to ticket #{ticket_id}")
                return followup_id
            else:
                logger.error(f"Failed to add followup: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Error adding followup: {e}")
            return None
    
    def add_solution(self, ticket_id: int, content: str) -> Optional[int]:
        """
        Add a solution to a ticket
        
        Args:
            ticket_id: The GLPI ticket ID
            content: Solution content
            
        Returns:
            Solution ID if created, None otherwise
        """
        try:
            if not self.session_token and not self.init_session():
                return None
            
            solution_data = {
                'input': {
                    'items_id': ticket_id,
                    'itemtype': 'Ticket',
                    'content': content,
                }
            }
            
            response = requests.post(
                f'{self.base_url}/ITILSolution',
                headers=self._get_headers(),
                json=solution_data,
                timeout=self._request_timeout
            )
            
            if response.status_code in [200, 201]:
                data = response.json()
                solution_id = data.get('id')
                logger.info(f"Added solution #{solution_id} to ticket #{ticket_id}")
                return solution_id
            else:
                logger.error(f"Failed to add solution: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Error adding solution: {e}")
            return None
    
    def get_ticket(self, ticket_id: int) -> Optional[Dict[str, Any]]:
        """Get ticket details by ID"""
        try:
            if not self.session_token and not self.init_session():
                return None
            
            response = requests.get(
                f'{self.base_url}/Ticket/{ticket_id}',
                headers=self._get_headers(),
                timeout=self._request_timeout
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Failed to get ticket: {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"Error getting ticket: {e}")
            return None
    
    def link_asset_to_ticket(self, ticket_id: int, itemtype: str, items_id: int) -> bool:
        """
        Link an asset to a ticket
        
        Args:
            ticket_id: The GLPI ticket ID
            itemtype: Asset type (e.g., 'Computer')
            items_id: Asset ID
            
        Returns:
            True if successful
        """
        try:
            if not self.session_token and not self.init_session():
                return False
            
            link_data = {
                'input': {
                    'tickets_id': ticket_id,
                    'itemtype': itemtype,
                    'items_id': items_id,
                }
            }
            
            response = requests.post(
                f'{self.base_url}/Item_Ticket',
                headers=self._get_headers(),
                json=link_data,
                timeout=self._request_timeout
            )
            
            if response.status_code in [200, 201]:
                logger.info(f"Linked {itemtype}#{items_id} to ticket #{ticket_id}")
                return True
            else:
                logger.warning(f"Failed to link asset: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Error linking asset: {e}")
            return False
    
    # =========================================================================
    # Asset Operations
    # =========================================================================
    
    def search_computer_by_serial(self, serial: str) -> Optional[Dict[str, Any]]:
        """Search for a computer by serial number"""
        return self._search_item('Computer', 'serial', serial)
    
    def search_computer_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Search for a computer by name"""
        return self._search_item('Computer', 'name', name)
    
    def search_network_equipment_by_serial(self, serial: str) -> Optional[Dict[str, Any]]:
        """Search for network equipment by serial number"""
        return self._search_item('NetworkEquipment', 'serial', serial)
    
    def search_network_equipment_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Search for network equipment by name"""
        return self._search_item('NetworkEquipment', 'name', name)
    
    def _search_item(self, itemtype: str, field: str, value: str) -> Optional[Dict[str, Any]]:
        """Generic item search"""
        try:
            if not self.session_token and not self.init_session():
                return None
            
            # Search criteria
            params = {
                'criteria[0][field]': self._get_search_field_id(itemtype, field),
                'criteria[0][searchtype]': 'equals',
                'criteria[0][value]': value,
                'forcedisplay[0]': 1,  # ID
                'forcedisplay[1]': 2,  # Name
            }
            
            response = requests.get(
                f'{self.base_url}/search/{itemtype}',
                headers=self._get_headers(),
                params=params,
                timeout=self._request_timeout
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get('data'):
                    return data['data'][0]
            return None
                
        except Exception as e:
            logger.error(f"Error searching {itemtype}: {e}")
            return None
    
    def _get_search_field_id(self, itemtype: str, field: str) -> int:
        """Map field names to GLPI search option IDs"""
        field_map = {
            'Computer': {'name': 1, 'serial': 5, 'otherserial': 6},
            'NetworkEquipment': {'name': 1, 'serial': 5, 'otherserial': 6},
        }
        return field_map.get(itemtype, {}).get(field, 1)
    
    def create_or_update_computer(self, data: Dict[str, Any]) -> Optional[int]:
        """
        Create or update a computer in GLPI
        
        Args:
            data: Computer data including 'name', 'serial', etc.
            
        Returns:
            Computer ID
        """
        try:
            if not self.session_token and not self.init_session():
                return None
            
            # Check if exists by serial
            existing = None
            if data.get('serial'):
                existing = self.search_computer_by_serial(data['serial'])
            elif data.get('name'):
                existing = self.search_computer_by_name(data['name'])
            
            if existing:
                # Update existing
                computer_id = existing.get('2') or existing.get('id')
                if computer_id:
                    data['id'] = computer_id
                    response = requests.put(
                        f'{self.base_url}/Computer/{computer_id}',
                        headers=self._get_headers(),
                        json={'input': data},
                        timeout=self._request_timeout
                    )
                    if response.status_code == 200:
                        logger.info(f"Updated computer #{computer_id}")
                        return int(computer_id)
            else:
                # Create new
                data['entities_id'] = GLPI_ENTITY_ID
                response = requests.post(
                    f'{self.base_url}/Computer',
                    headers=self._get_headers(),
                    json={'input': data},
                    timeout=self._request_timeout
                )
                if response.status_code in [200, 201]:
                    result = response.json()
                    computer_id = result.get('id')
                    logger.info(f"Created computer #{computer_id}")
                    return computer_id
            
            return None
                
        except Exception as e:
            logger.error(f"Error creating/updating computer: {e}")
            return None
    
    def get_all_computers(self, fields: List[str] = None) -> List[Dict[str, Any]]:
        """Get all computers from GLPI"""
        try:
            if not self.session_token and not self.init_session():
                return []
            
            computers = []
            start = 0
            limit = 100
            
            while True:
                params = {
                    'range': f'{start}-{start + limit - 1}',
                    'expand_dropdowns': 'false',
                }
                
                response = requests.get(
                    f'{self.base_url}/Computer',
                    headers=self._get_headers(),
                    params=params,
                    timeout=self._request_timeout
                )
                
                if response.status_code == 200:
                    data = response.json()
                    if isinstance(data, list):
                        computers.extend(data)
                        if len(data) < limit:
                            break
                        start += limit
                    else:
                        break
                else:
                    break
            
            return computers
                
        except Exception as e:
            logger.error(f"Error getting computers: {e}")
            return []
