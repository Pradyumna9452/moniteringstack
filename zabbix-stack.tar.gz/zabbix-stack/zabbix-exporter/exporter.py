#!/usr/bin/env python3
"""
Zabbix to VictoriaMetrics Exporter
Fetches metrics from Zabbix API and exports them to VictoriaMetrics
"""

import os
import time
import json
import logging
from datetime import datetime
import requests

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Configuration from environment variables
ZABBIX_URL = os.environ.get('ZABBIX_URL', 'http://zabbix-web:8080/api_jsonrpc.php')
ZABBIX_USER = os.environ.get('ZABBIX_USER', 'Admin')
ZABBIX_PASSWORD = os.environ.get('ZABBIX_PASSWORD', 'zabbix')
VM_URL = os.environ.get('VM_URL', 'http://victoriametrics:8428')
EXPORT_INTERVAL = int(os.environ.get('EXPORT_INTERVAL', 60))


class ZabbixClient:
    """Zabbix API Client"""
    
    def __init__(self):
        self.url = ZABBIX_URL
        self.auth_token = None
        self.request_id = 0
        
    def _call(self, method, params=None):
        """Make Zabbix API call"""
        self.request_id += 1
        payload = {
            'jsonrpc': '2.0',
            'method': method,
            'params': params or {},
            'id': self.request_id
        }
        
        headers = {'Content-Type': 'application/json'}
        
        # Zabbix 7.x uses Authorization header instead of auth parameter
        if self.auth_token and method != 'user.login':
            headers['Authorization'] = f'Bearer {self.auth_token}'
        
        try:
            response = requests.post(
                self.url,
                headers=headers,
                json=payload,
                timeout=30
            )
            data = response.json()
            
            if 'error' in data:
                logger.error(f"Zabbix API error: {data['error']}")
                return None
            
            return data.get('result')
            
        except Exception as e:
            logger.error(f"Error calling Zabbix API: {e}")
            return None
    
    def login(self):
        """Authenticate with Zabbix"""
        result = self._call('user.login', {
            'username': ZABBIX_USER,
            'password': ZABBIX_PASSWORD
        })
        
        if result:
            self.auth_token = result
            logger.info("Successfully authenticated with Zabbix")
            return True
        
        # Try with 'user' parameter for older Zabbix versions
        result = self._call('user.login', {
            'user': ZABBIX_USER,
            'password': ZABBIX_PASSWORD
        })
        
        if result:
            self.auth_token = result
            logger.info("Successfully authenticated with Zabbix (legacy)")
            return True
            
        logger.error("Failed to authenticate with Zabbix")
        return False
    
    def get_hosts(self):
        """Get all monitored hosts"""
        return self._call('host.get', {
            'output': ['hostid', 'host', 'name'],
            'selectInterfaces': ['ip'],
            'filter': {'status': 0}  # Enabled hosts only
        }) or []
    
    def get_items(self, hostids=None):
        """Get items (metrics) from hosts"""
        params = {
            'output': ['itemid', 'name', 'key_', 'lastvalue', 'lastclock', 'units'],
            'filter': {'status': 0},  # Enabled items only
            'selectHosts': ['host', 'name']
        }
        if hostids:
            params['hostids'] = hostids
            
        return self._call('item.get', params) or []
    
    def get_triggers(self):
        """Get active triggers/problems"""
        return self._call('trigger.get', {
            'output': ['triggerid', 'description', 'priority', 'value', 'lastchange'],
            'selectHosts': ['host', 'name'],
            'filter': {'value': 1},  # Problem state
            'only_true': 1,
            'active': 1
        }) or []


class VictoriaMetricsClient:
    """VictoriaMetrics Client"""
    
    def __init__(self):
        self.url = VM_URL
        
    def write_metrics(self, metrics):
        """Write metrics to VictoriaMetrics using import endpoint"""
        if not metrics:
            return True
            
        try:
            # Format metrics in Prometheus format
            lines = []
            for metric in metrics:
                name = metric['name']
                value = metric['value']
                timestamp = metric.get('timestamp', int(time.time() * 1000))
                labels = metric.get('labels', {})
                
                # Build label string
                if labels:
                    label_str = ','.join([f'{k}="{v}"' for k, v in labels.items()])
                    lines.append(f'{name}{{{label_str}}} {value} {timestamp}')
                else:
                    lines.append(f'{name} {value} {timestamp}')
            
            data = '\n'.join(lines)
            
            response = requests.post(
                f'{self.url}/api/v1/import/prometheus',
                headers={'Content-Type': 'text/plain'},
                data=data,
                timeout=30
            )
            
            if response.status_code in [200, 204]:
                logger.debug(f"Successfully wrote {len(metrics)} metrics to VictoriaMetrics")
                return True
            else:
                logger.error(f"Failed to write metrics: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Error writing to VictoriaMetrics: {e}")
            return False
    
    def health_check(self):
        """Check VictoriaMetrics health"""
        try:
            response = requests.get(f'{self.url}/health', timeout=5)
            return response.status_code == 200
        except:
            return False


def sanitize_metric_name(name):
    """Convert Zabbix item name to valid Prometheus metric name"""
    import re
    # Replace invalid characters with underscore
    name = re.sub(r'[^a-zA-Z0-9_:]', '_', name)
    # Ensure it starts with a letter or underscore
    if name and name[0].isdigit():
        name = '_' + name
    # Remove consecutive underscores
    name = re.sub(r'_+', '_', name)
    return name.lower().strip('_')


def export_metrics(zabbix, vm):
    """Export Zabbix metrics to VictoriaMetrics"""
    try:
        # Get enabled hosts first
        hosts = zabbix.get_hosts()
        host_ids = [h['hostid'] for h in hosts]
        
        # Get items only from enabled hosts (not templates)
        items = zabbix.get_items(hostids=host_ids)
        logger.info(f"Retrieved {len(items)} items from {len(hosts)} hosts")
        
        metrics = []
        
        # =====================================================
        # CRITICAL: Add host_alive metric for each enabled host
        # This enables dynamic host discovery via label_values()
        # and staleness-based auto-removal in Grafana
        # =====================================================
        current_time_ms = int(time.time() * 1000)
        for host in hosts:
            hostname = host.get('host', 'unknown')
            host_display_name = host.get('name', hostname)
            
            # Get host IP if available
            interfaces = host.get('interfaces', [])
            host_ip = interfaces[0].get('ip', '') if interfaces else ''
            
            metrics.append({
                'name': 'zabbix_host_alive',
                'value': 1,  # 1 = host is monitored and enabled
                'timestamp': current_time_ms,
                'labels': {
                    'host': hostname,
                    'host_name': host_display_name[:50],
                    'host_ip': host_ip,
                    'source': 'zabbix'
                }
            })
        
        logger.info(f"Added {len(hosts)} host_alive heartbeat metrics for dynamic discovery")
        
        for item in items:
            try:
                # Skip items without numeric values
                lastvalue = item.get('lastvalue', '')
                if not lastvalue or lastvalue == '':
                    continue
                    
                # Try to convert to float
                try:
                    value = float(lastvalue)
                except (ValueError, TypeError):
                    continue
                
                # Get host info
                hosts = item.get('hosts', [])
                hostname = hosts[0]['host'] if hosts else 'unknown'
                
                # Create metric
                metric_name = f"zabbix_{sanitize_metric_name(item.get('key_', item.get('name', 'unknown')))}"
                
                metrics.append({
                    'name': metric_name,
                    'value': value,
                    'timestamp': int(item.get('lastclock', time.time())) * 1000,
                    'labels': {
                        'host': hostname,
                        'item': item.get('name', 'unknown')[:50],  # Truncate long names
                        'source': 'zabbix'
                    }
                })
                
            except Exception as e:
                logger.debug(f"Error processing item: {e}")
                continue
        
        # Export trigger/problem count as a metric
        triggers = zabbix.get_triggers()
        
        # Count triggers by priority
        priority_counts = {0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
        for trigger in triggers:
            priority = int(trigger.get('priority', 0))
            priority_counts[priority] = priority_counts.get(priority, 0) + 1
        
        priority_names = {
            0: 'not_classified',
            1: 'information', 
            2: 'warning',
            3: 'average',
            4: 'high',
            5: 'disaster'
        }
        
        for priority, count in priority_counts.items():
            metrics.append({
                'name': 'zabbix_active_triggers',
                'value': count,
                'labels': {
                    'priority': priority_names.get(priority, str(priority)),
                    'source': 'zabbix'
                }
            })
        
        # Total problem count
        metrics.append({
            'name': 'zabbix_total_problems',
            'value': len(triggers),
            'labels': {'source': 'zabbix'}
        })
        
        # Write to VictoriaMetrics
        if metrics:
            vm.write_metrics(metrics)
            logger.info(f"Exported {len(metrics)} metrics to VictoriaMetrics")
        else:
            logger.warning("No metrics to export")
            
    except Exception as e:
        logger.error(f"Error exporting metrics: {e}")


def main():
    """Main export loop"""
    logger.info("Starting Zabbix to VictoriaMetrics Exporter")
    logger.info(f"Zabbix URL: {ZABBIX_URL}")
    logger.info(f"VictoriaMetrics URL: {VM_URL}")
    logger.info(f"Export interval: {EXPORT_INTERVAL}s")
    
    zabbix = ZabbixClient()
    vm = VictoriaMetricsClient()
    
    # Wait for services to be ready
    logger.info("Waiting for services to be ready...")
    time.sleep(30)
    
    while True:
        try:
            # Check VictoriaMetrics health
            if not vm.health_check():
                logger.warning("VictoriaMetrics not healthy, waiting...")
                time.sleep(10)
                continue
            
            # Authenticate with Zabbix
            if not zabbix.auth_token:
                if not zabbix.login():
                    logger.warning("Failed to login to Zabbix, retrying in 30s...")
                    time.sleep(30)
                    continue
            
            # Export metrics
            export_metrics(zabbix, vm)
            
        except Exception as e:
            logger.error(f"Error in export loop: {e}")
            zabbix.auth_token = None  # Force re-authentication
        
        time.sleep(EXPORT_INTERVAL)


if __name__ == '__main__':
    main()
