#!/bin/bash
# ============================================
# ZABBIX STACK RESTORE SCRIPT
# Usage: ./restore.sh /path/to/backup/folder
# ============================================

set -e

# Check if backup directory is provided
if [ -z "$1" ]; then
    echo "============================================"
    echo "  ZABBIX STACK RESTORE"
    echo "============================================"
    echo ""
    echo "Usage: $0 /path/to/backup/folder"
    echo ""
    echo "Available backups:"
    ls -lh /root/ | grep zabbix-backup || echo "No backups found in /root/"
    echo ""
    exit 1
fi

BACKUP_DIR="$1"

# Verify backup exists
if [ ! -d "$BACKUP_DIR" ]; then
    echo "ERROR: Backup directory not found: $BACKUP_DIR"
    exit 1
fi

echo "============================================"
echo "  ZABBIX STACK RESTORE"
echo "  $(date)"
echo "============================================"
echo ""
echo "Backup source: $BACKUP_DIR"
echo ""
echo "Contents:"
ls -lh $BACKUP_DIR
echo ""
read -p "This will OVERWRITE existing data. Continue? (y/N): " confirm
if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
    echo "Restore cancelled."
    exit 0
fi

echo ""
echo "Starting restore..."
echo ""

# 1. Stop all containers
echo "[1/9] Stopping all containers..."
cd ~/zabbix-stack
docker-compose down 2>/dev/null || true
sleep 5

# 2. Restore config files (nginx, docker-compose, SSL, etc.)
echo "[2/9] Restoring config files..."
if [ -d "$BACKUP_DIR/zabbix-stack-files" ]; then
    # Backup current configs first
    cp -r ~/zabbix-stack ~/zabbix-stack.old.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
    # Restore from backup
    cp -r $BACKUP_DIR/zabbix-stack-files/* ~/zabbix-stack/
    echo "  - Config files restored"
else
    echo "  - WARNING: zabbix-stack-files not found in backup"
fi

# 3. Start database containers first
echo "[3/9] Starting database containers..."
cd ~/zabbix-stack
docker-compose up -d postgres mariadb-glpi 2>/dev/null || docker-compose up -d zabbix-postgres glpi-mariadb 2>/dev/null || true
echo "  - Waiting 20 seconds for databases to initialize..."
sleep 20

# 4. Restore PostgreSQL (Zabbix database)
echo "[4/9] Restoring Zabbix PostgreSQL database..."
if [ -f "$BACKUP_DIR/zabbix_postgres_backup.sql.gz" ]; then
    # Drop and recreate database for clean restore
    docker exec zabbix-postgres psql -U zabbix -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;" 2>/dev/null || true
    gunzip -c $BACKUP_DIR/zabbix_postgres_backup.sql.gz | docker exec -i zabbix-postgres psql -U zabbix zabbix 2>/dev/null
    echo "  - PostgreSQL database restored"
else
    echo "  - WARNING: PostgreSQL backup not found"
fi

# 5. Restore MariaDB (GLPI database)
echo "[5/9] Restoring GLPI MariaDB database..."
if [ -f "$BACKUP_DIR/glpi_mariadb_backup.sql.gz" ]; then
    gunzip -c $BACKUP_DIR/glpi_mariadb_backup.sql.gz | docker exec -i glpi-mariadb mysql -uglpi -pglpi_password glpi 2>/dev/null
    echo "  - MariaDB database restored"
else
    echo "  - WARNING: MariaDB backup not found"
fi

# 6. Restore Grafana data
echo "[6/9] Restoring Grafana data..."
if [ -f "$BACKUP_DIR/grafana_data.tar.gz" ]; then
    docker run --rm -v zabbix-stack_grafana_data:/data -v $BACKUP_DIR:/backup alpine sh -c "rm -rf /data/* && tar xzf /backup/grafana_data.tar.gz -C /data" 2>/dev/null
    echo "  - Grafana data restored"
else
    echo "  - WARNING: Grafana backup not found"
fi

# 7. Restore VictoriaMetrics data
echo "[7/9] Restoring VictoriaMetrics data..."
if [ -f "$BACKUP_DIR/victoriametrics_data.tar.gz" ]; then
    docker run --rm -v zabbix-stack_victoriametrics_data:/data -v $BACKUP_DIR:/backup alpine sh -c "rm -rf /data/* && tar xzf /backup/victoriametrics_data.tar.gz -C /data" 2>/dev/null
    echo "  - VictoriaMetrics data restored"
else
    echo "  - WARNING: VictoriaMetrics backup not found"
fi

# 8. Restore GLPI files
echo "[8/9] Restoring GLPI files..."
if [ -f "$BACKUP_DIR/glpi_data.tar.gz" ]; then
    docker run --rm -v zabbix-stack_glpi_data:/data -v $BACKUP_DIR:/backup alpine sh -c "rm -rf /data/* && tar xzf /backup/glpi_data.tar.gz -C /data" 2>/dev/null
    echo "  - GLPI data restored"
fi
if [ -f "$BACKUP_DIR/glpi_config.tar.gz" ]; then
    docker run --rm -v zabbix-stack_glpi_config:/data -v $BACKUP_DIR:/backup alpine sh -c "rm -rf /data/* && tar xzf /backup/glpi_config.tar.gz -C /data" 2>/dev/null
    echo "  - GLPI config restored"
fi
if [ -f "$BACKUP_DIR/glpi_files.tar.gz" ]; then
    docker run --rm -v zabbix-stack_glpi_files:/data -v $BACKUP_DIR:/backup alpine sh -c "rm -rf /data/* && tar xzf /backup/glpi_files.tar.gz -C /data" 2>/dev/null
    echo "  - GLPI files restored"
fi

# 9. Start all services
echo "[9/9] Starting all services..."
cd ~/zabbix-stack
docker-compose up -d
echo "  - Waiting 30 seconds for services to start..."
sleep 30

echo ""
echo "============================================"
echo "  RESTORE COMPLETE"
echo "============================================"
echo ""
echo "Container Status:"
docker-compose ps
echo ""
echo "Testing Services:"
echo -n "  Zabbix:  "; curl -k -s -o /dev/null -w "%{http_code}" https://localhost/zabbix/ 2>/dev/null || echo "FAIL"
echo -n "  Grafana: "; curl -k -s -o /dev/null -w "%{http_code}" https://localhost/grafana/ 2>/dev/null || echo "FAIL"
echo -n "  GLPI:    "; curl -k -s -o /dev/null -w "%{http_code}" https://localhost/glpi/ 2>/dev/null || echo "FAIL"
echo ""
echo "============================================"
echo "  Access URLs:"
echo "  - Zabbix:  https://YOUR_IP/zabbix/"
echo "  - Grafana: https://YOUR_IP/grafana/"
echo "  - GLPI:    https://YOUR_IP/glpi/"
echo "============================================"
